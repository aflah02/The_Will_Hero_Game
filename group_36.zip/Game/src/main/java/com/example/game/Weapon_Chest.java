package com.example.game;

import javafx.scene.image.ImageView;

public class Weapon_Chest extends Chest{
    @Override
    public void collide(Player player) {

    }

    @Override
    public ImageView getImage() {
        return null;
    }
}
