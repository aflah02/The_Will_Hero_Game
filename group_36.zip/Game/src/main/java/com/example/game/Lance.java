package com.example.game;

public class Lance extends Weapon{
    @Override
    int getDamage() {
        return 0;
    }

    @Override
    int setDamage() {
        return 0;
    }

    @Override
    int getRadius() {
        return 0;
    }

    @Override
    int increaseLevel() {
        return 0;
    }
}
